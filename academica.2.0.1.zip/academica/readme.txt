= ACADEMICA =

* by WPZOOM, http://wpzoom.com/

== ABOUT ACADEMICA ==

Academica is an education- and school-oriented CMS theme with a three-column layout and modern design. It is easy to customize and comes with a custom widget, three templates for Posts and Pages.

Please note:
The Footer Menu is best suitable for short menues with just a few links, as it only supports one menu level.

== Changelog ==

= 2.0.1 (May 8, 2016) =
* Added TGM Plugin Activator in order to installed recommended plugins used by the theme easier
* Minor bug fixes

= 2.0 (March 26, 2015) =
* Theme re-design and major updates, including many modifications.
* All files were modified

= 1.2.2-wpcom (October 1, 2012) =
* Converted for use on WordPress.com

= 1.2.2 (December 13, 2011) =
* An update for WP 3.3
* Files edited: header.php, style.css

= 1.2 (August 6, 2011) =
* An important security fix: /scripts/timthumb.php has been updated to 2.0

= 1.1 (July 20, 2011) =
* theme moved to new back-end interface of WPZOOM
* overall theme improvements, all files have been modified

= 1.0 (August 18, 2010) =
* initial release