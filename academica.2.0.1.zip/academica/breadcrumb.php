<?php
/**
 * @package Academica
 */
?>
<div id="crumbs">
	<p><?php academica_breadcrumbs(); ?></p>
</div><!-- end #crumbs -->